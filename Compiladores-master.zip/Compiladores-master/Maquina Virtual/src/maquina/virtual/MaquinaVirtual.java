package maquina.virtual;


public class MaquinaVirtual {

    public static void main(String[] args) {
        teste teste = new teste();
        teste.setVisible(true);
        // TODO code application logic here
        //MainFrame main_frame = new MainFrame();
        //main_frame.setUndecorated(true);
        //main_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //main_frame.setSize(1000, 700);
        //main_frame.setLocationRelativeTo(null);
        //main_frame.setVisible(true);
        //main_frame.setResizable(false);
        
    }

}
